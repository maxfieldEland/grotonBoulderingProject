
<!-- ######################     Main Navigation   ########################## -->

<nav> 
    <ol>
        
        <?php
        
        #link to climb submission page
        
        print '<li class ="';
        if( $path_parts['filename']=="submit"){
            print 'activePage ';
        }
        print '">';
        print '<a href="submit.php">Submit Climb</a>';
        print '</li>';
        
        
        # link to Climbs List
        print '<li class ="';
        if( $path_parts['filename']=="areas"){
            print 'activePage ';
        }
        print '">';
        print '<a href="bouldering-details.php">Developed Problems</a>';
        print '</li>';
        
        # link to why groton page
        print '<li class ="';
        if( $path_parts['filename']=="whygroton"){
            print 'activePage ';
        }
        print '">';
        print '<a href="whygroton.php">Why Groton?</a>';
        print '</li>';
        
        
        ?>
        
    </ol>
</nav>

