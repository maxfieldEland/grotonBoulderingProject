

<!DOCTYPE HTML>
<html lang="en">

    <head>
        <title>Groton Boulder Project</title>
        <meta charset="utf-8">
        <meta name="author" content="Maxfield Green and Colby Yee">
        <meta name="description" content="A site map for the groton boulder project">
        <link rel="stylesheet" href="custom.css" type="text/css" media="screen">
    </head>

    <body id = "home">
        <h1 align = "center" >Welcome to the Groton Boulder Project</h1>
        <p align = "center"> Here you will find an interactive and comprehensive guide to bouldering in Groton State Forest</p>

        <ul align = "center">
            <li><a href="whygroton.php">Why Groton</a></li>
            <li><a href ="maps.php"> Map of Areas</a></li>
            <li><a href ="bouldering-details.php"> Areas </a></li>
            <li><a href ="media.php"> Media </a></li>
            <li><a href ="submit.php"> Add Climb!</a></li>
 
        </ul>
    </body>
</html>
