<?php
include 'top.php';

// define security variable
$thisURL = $domain . $phpSelf;

// form variables
$boulderName = "default"; // name of boulder
$climbName = "defualt"; // name of climb
$grade = "soft v4"; // grade of climb
$oneStar = true; // quality of climb
$twoStar = true;
$threeStar = true;
$bomb = true;


// form error flags

$emailNameERROR = false;
$climbNameERROR = false;
$gradeERROR = false;
$boulderNameERROR = false;
// quality rating
$activityERROR = false;

// Misc varibales
// create array to hold error messages 

$errorMsg = array();
// array to hold form data that will be written to CSV
$dataRecord = array();

$totalChecked = 0;

// Process for when the climber submits the climb to data base

if (isset($_POST["btnSubmit"])) {
    // security
    if (!securityCheck($thisURL)) {
        $msg = '<p>Sorry you cannot access this page. ';
        $msg.= 'Security breach detected and reported.</p>';
        die($msg);
    }

    // sanatize incoming data
    //Two write in boxes for climb and boulder name
    $boulderName = htmlentities($_POST["txtBoulderName"], ENT_QUOTES, "UTF-8");
    $dataRecord[] = $boulderName;
    $climbName = htmlentities($_POST["txtClimbName"], ENT_QUOTES, "UTF-8");
    $dataRecord[] = $climbName;
    
    // grade of climb
    $grade = htmlentities($_POST["lstGrade"], ENT_QUOTES, "UTF-8");
    $dataRecord[] = $grade;
    
    //  Four check options for climb quality rating
    if (isset($_POST["chkOneStar"])) {
        $oneStar = true;
        $totalChecked++;
        $dataRecord[] = '*';
    } else {
        $oneStar = false;
    }

    if (isset($_POST["chkTwoStar"])) {
        $twoStar = true;
        $totalChecked++;
        $dataRecord[] = '**';
    } else {
        $twoStar = false;
    }
    
    if (isset($_POST["chkThreeStar"])) {
        $threeStar = true;
        $totalChecked++;
        $dataRecord[] = '***';
    } else {
        $threeStar = false;
    }
    

    if (isset($_POST["chkBomb"])) {
        $bomb = true;
        $totalChecked++;
        $dataRecord[] = 'bomb';
    } else {
        $bomb = false;
    }
    
    // validation
    
    // Boulder name
    if ($boulderName == "") {
        $errorMsg[] = "Please enter the boulder name ";
        $boulderNameERROR = true;
    } elseif (!verifyAlphaNum($boulderName)) {
        $errorMsg[] = "The boulder name appears to have extra character.";
        $boulderNameERROR = true;
    }
    // climb name
    if ($climbName == "") {
        $errorMsg[] = "Please enter the climb name ";
        $climbNameERROR = true;
    } elseif (!verifyAlphaNum($boulderName)) {
        $errorMsg[] = "The climb name appears to have extra character.";
        $climbNameERROR = true;
    }
    //grade of climb
    if ($grade == "soft v4") {
        $errorMsg[] = "Please choose a legit grade, ya sandbagger!";
        $gradeERROR = true;
    }

   

    // process form - passed validation
    if (!$errorMsg) {
        if ($debug)
            print PHP_EOL . '<p>Form is valid</p>';

        // save form data to CSV File

        $myFolder = 'data/';
        $myFileName = 'submission';
        $fileExt = '.csv';

        $filename = $myFolder . $myFileName . $fileExt;
        if ($debug)
            print PHP_EOL . '<p>filename is ' . $filename;

        // open the file for appending new row
        $file = fopen($filename, 'a');

        // write the new information from the submission
        // add information that has been written into $dataRecord
        fputcsv($file, $dataRecord);

        // close file
        fclose($file);
        
        // Create message to display to submitter
        
        $message = '<h2>Thanks for contributing<h2>';
        $message .= '<p>Your climb has been logged as:<p>';
        
        foreach ($_POST as $htmlName => $value) {

            $message .= '<p>';
            // breaks up the form names into words. for example
            // txtFirstName becomes First Name
            $camelCase = preg_split('/(?=[A-Z])/', substr($htmlName, 3));

            foreach ($camelCase as $oneWord) {
                $message .= $oneWord . ' ';
            }
            $message .= ' = ' . htmlentities($value, ENT_QUOTES, "UTF-8") . '</p>';
        }
    }// end form is valid
} // end if form was submitted.   

// Display Form
?>

<article id ="main">

<?php
// message to form submiter

if (isset($_POST["btnSubmit"]) AND empty($errorMsg)) { // closing of this if statement marked with: end body submit
    
    // stuff to show if the data has already been entered
    print '<h2>Thank you for adding a climb to the database.</h2>';
    print '<p>Your contributions will not go unnoticed.</p>';
} else {
    
    // stuff to show at the top of the form
    print '<h2> Submit your newest climb today!</h2>';
    print '<h2> Contribute to the Vermont Climbing Community! </h2>';
    
// Error messages

    if ($errorMsg) {
        print '<div id = "errors">' . PHP_EOL;
        print '<h2>Your form has the following mistakes that need to be fixed.</h2>' . PHP_EOL;
        print '<ol>' . PHP_EOL;

        foreach ($errorMsg as $err) {
            print '<li>' . $err . '</li>' . PHP_EOL;
        }

        print '</ol>' . PHP_EOL;
        print '</div>' . PHP_EOL;
    }

    // html form
    ?>
    
        <form action="<?php print $phpSelf; ?>"
              id ="frmSubmission "
              method="post">

            <fieldset class = "contact">
                <legend>Climb Information</legend>
                <p>
                    <label class ="required text-field" for ="txtBoulderName" >Boulder Name</label>
                    <input autofocus
                    <?php if ($boulderNameERROR) print 'class = "mistake"'; ?>
                           id="txtBoulderName"
                           maxlength ="45"
                           name="txtBoulderName"
                           onfocus ="this.select()"
                           placeholder ="Enter boulder name "
                           tabindex="100"
                           type ="text"
                           value ="<?php print $boulderName; ?>"
                           >
                </p>

                <p>
                    <label class ="required text-field" for ="txtClimbName ">Climb Name</label>
                    <input autocomplete
                    <?php if ($climbNameERROR) print 'class = "mistake"'; ?>
                           id ="txtClimbName"
                           maxlength ="45"
                           name="txtClimbName"
                           onfocus ="this.select()"
                           placeholder ="Enter the climb name "
                           tabindex="100"
                           type ="text"
                           value ="<?php print $climbName; ?>"
                           >
                </p>

            </fieldset>

            <fieldset  class="listbox <?php if ($gradeERROR) print ' mistake'; ?>">
                <p>
                <legend>Grade of Climb</legend>
                <select id="lstGrade" 
                        name="lstGrade" 
                        tabindex="520" >
                    <option <?php if ($grade == "soft v4") print " selected "; ?>
                        value="soft v4">soft v4</option>
                    <option <?php if ($grade == "v1") print " selected "; ?>
                        value="V1">V1</option>

                    <option <?php if ($grade == "v2") print " selected "; ?>
                        value="V2">V2</option>

                    <option <?php if ($grade == "v3") print " selected "; ?>
                        value="V3">V3</option>

                    <option <?php if ($grade == "v4") print " selected "; ?>
                        value="V4">V4</option>

                    <option <?php if ($grade == "v5") print " selected "; ?>
                        value="V5">V5</option>
                    <option <?php if ($grade == "v6") print " selected "; ?>
                        value="V6">V6</option>
                    <option <?php if ($grade == "v7") print " selected "; ?>
                        value="V7">V7</option>
                    <option <?php if ($grade == "v8") print " selected "; ?>
                        value="V8">V8</option>
                    <option <?php if ($grade == "v9") print " selected "; ?>
                        value="V9">V9</option>
                    <option <?php if ($grade == "v10") print " selected "; ?>
                        value="V10">V10</option>
                    <option <?php if ($grade == "v11") print " selected "; ?>
                        value="V11">V11</option>
                    <option <?php if ($grade == "v12") print " selected "; ?>
                        value="12">V12</option>
                    <option <?php if ($grade == "v13") print " selected "; ?>
                        value="V13">V13</option>
                    <option <?php if ($grade == "v14") print " selected "; ?>
                        value="V14">V14</option>
                </select>
                </p>
            </fieldset>
            
            <fieldset class="checkbox <?php if ($activityERROR) print ' mistake'; ?>">
                <legend>Quality Rating</legend>
                <p>
                    <label class="check-field">
                        <input <?php if ($oneStar) print " checked "; ?> 
                               id="rad" 
                               name="chkOneStar" 
                               tabindex="572"
                               type ="checkbox"
                               value="oneStar">*</label>
                             
                </p>

                <p>
                    <label class="check-field">
                        <input <?php if ($twoStar) print " checked "; ?> 
                               id="rad" 
                               name="chkTwoStar" 
                               tabindex="572"
                               type ="checkbox"
                               value="twoStar">**</label> 
                        
                </p>

                <p>
                    <label class="check-field">
                        <input <?php if ($threeStar) print " checked "; ?> 
                               id="rad" 
                               name="chkThreeStar" 
                               tabindex="572"
                               type ="checkbox"
                               value="threeStar">***</label> 

                </p>

                <p>
                    <label class="check-field">
                        <input <?php if ($bomb) print " checked "; ?> 
                               id="rad" 
                               name="chkBomb" 
                               tabindex="572"
                               type ="checkbox"
                               value="Bomb" >BOMB!</label>
                </p>
            </fieldset>
       
            <fieldset class="buttons">
                <legend></legend>
                <input class="button" id="btnSubmit" name="btnSubmit" tabindex="900" type="submit" value="Submit Climb" >                
            </fieldset>
        </form>
    <?php
    
    } //end body submit
    ?>

</article>
</body>
</html>



