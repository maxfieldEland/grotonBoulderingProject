<!-- ######################     Page header   ############################## -->
<header>
    <h1>GROTON CLIMBING PROJECT</h1>
</header>