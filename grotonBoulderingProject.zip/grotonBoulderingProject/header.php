<!-- ######################     Page header   ############################## -->
<meta charset="utf-8">
        <meta name="author" content="Maxfield Green and Colby Yee">
        <meta name="description" content="A site map for the groton boulder project">
        <link rel="stylesheet" href="custom.css" type="text/css" media="screen">

<header>
    <h1><a href="projectmap.php">Groton Bouldering Project</a></h1>
</header>