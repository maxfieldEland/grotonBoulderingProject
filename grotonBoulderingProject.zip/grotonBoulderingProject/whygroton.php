<?php
include 'top.php';
?>
<!DOCTYPE HTML>
<html lang="en">

    <head>
        <title>Groton Bouldering Project</title>
        <meta charset="utf-8">
        <meta name="author" content="Maxfield Green and Colby Yee">
        <meta name="description" content="why groton is cool">
        <link rel="stylesheet" href="custom.css" type="text/css" media="screen">
    </head>

    <body id = "whygroton">
        <h1 align = "middle" >Welcome to the Yosemite Boulder-field of Vermont</h1>
        
        
        <p> Groton State Forest currently contains about 20-30 developed Boulder Problems. With blocs ranging in size from a mini fridge to your neighbour's rich auntie's
            home in the Florida Key's, Groton has something of the right size for everyone. In 2017, local climbing advocate Donny the Contractor gave Colby and I a digital pamflet cataloging some of 
            the Green Mountain State's choseist lines. The booklet described Groton State Forest as a 'granite junkies paradise'. Granite in Vermont? That doesnt sound right. Despite a stiff
            local obsession with Vermont's hardlines, most of the boulders here are total crap. Thinking we were embarking on yet another wild goose chase, Colby and I set out
            to search the Groton grounds for the so-called "Gem Boulder". After much mucking around following typical trash climbing directions, we did find the Gem. Low and behold, 
            we stood eagerly in front of a beautiful 20 foot boulder. 
        </p>
    </body>
</html>